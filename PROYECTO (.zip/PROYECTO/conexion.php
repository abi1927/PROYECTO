<?php
$conexion = new mysqli ("localhost", "root","","inventario");
?>