<?php
require ('conexion.php');
$nombre=$_POST ['nombre_pieza'];
$existencia=$_POST ['existencia_pieza'];
$precio=$_POST ['precio_pieza'];

$query="insert into inventario_de_piezas(nombre_pieza, existencia_pieza, precio_pieza) 
values ('$nombre','$existencia','$precio')" ;

$resultado=$conexion->query($query);
if ($resultado) {
	header ("Location: mostrar_piezas.php");
}
else{
	echo "insercion no exitosa";
}
	

?>