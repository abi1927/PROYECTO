
<HTML>
<title>Nueva Pieza</title>
<HEAD>
	<meta charset="utf-8">
   <meta name ="viewport " content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</HEAD>
    <body>

<link rel="stylesheet" type="text/css" href="menu_estidlo.css">

<nav class ="navbar navbar-inverse">
<div class=container-fluid >

<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a style="color:#FF0000" class ="navbar-brand" href="index.html">Inicio</a>

</div>
<div  class="collapse navbar-collapse" id="myNavbar">
<u1 class="nav navbar-nav">

<li style="color:#FF0000">Usuarios
	<ul>
		<li><a href="mostrar_usuarios.php" style="color:#FF0000">Usuarios </a></li>
		<li><a href="alta_usuarios.php" style="color:#FF0000">Nuevo usuario </a></li>
	</ul>
</li>
<li style="color:#FF0000">Piezas
	<ul>
		<li><a href="mostrar_piezas.php" style="color:#FF0000">Piezas</a></li>
		<li><a href="alta_piezas.php" style="color:#FF0000">Nueva pieza </a></li>
	</ul>
</li >
 <li style="color:#FF0000">Calidad
	<ul>
		<li><a href="error.php" style="color:#FF0000">Indicadores de Calidad</a></li>
		<li><a href="error.php" style="color:#FF0000">Nuevo Registro</a></li>
	</ul>
</li>


</u1>


</div>
 </div>
 </nav>
 <br>



<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	 <H1>Nueva Pieza</H1>
	 	<!--FORMULARIO!--->
	<FORM ACTION = 'proceso_alta_pieza.php' METHOD = 'POST' >



	 <LABEL> NOMBRE:  </LABEL>
	   <INPUT TYPE = "TEXT" NAME = "nombre_pieza" id="nombre_pieza" class="form-control"/></BR></BR>


	   <LABEL> EXISTENCIA:  </LABEL>
	   <INPUT TYPE = "TEXT" NAME = "existencia_pieza" id="existencia_pieza" class="form-control"/></BR></BR>

	     <LABEL> PRECIO:  </LABEL>
	   <INPUT TYPE = "TEXT" NAME = "precio_pieza" id="precio_pieza" class="form-control"/></BR></BR>




	   <BUTTON TYPE = 'submit' NAME= 'submit' class="btn btn-default">Enviar datos</BUTTON>

	  </FORM>

	</BODY>

</HTML>
