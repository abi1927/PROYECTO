<?php
require ('conexion.php');
$nombre=$_POST ['nombre_usuario'];
$apellido=$_POST ['apellido_usuario'];
$rfc=$_POST ['rfc'];

$query="insert into usuarios(nombre_usuario, apellido_usuario, rfc) values ('$nombre','$apellido','$rfc')" ;

$resultado=$conexion->query($query);
if ($resultado) {
	header ("Location: mostrar_usuarios.php");
}
else{
	echo "insercion no exitosa";
}
	

?>